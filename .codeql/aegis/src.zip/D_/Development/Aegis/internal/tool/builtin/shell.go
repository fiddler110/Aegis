package builtin

import (
	"context"
	"encoding/json"
	"fmt"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/fiddler110/aegis/internal/checkpoint"
	"github.com/fiddler110/aegis/internal/sandbox"
	"github.com/fiddler110/aegis/internal/task"
	"github.com/fiddler110/aegis/internal/tool"
)

type shellTool struct {
	root       string
	timeoutSec int
	mgr        *task.Manager   // optional; enables background:true
	sb         sandbox.Backend // optional; nil = inline local exec (legacy path)
}

func newShellTool(root string, timeoutSec int, mgr *task.Manager, sb sandbox.Backend) *shellTool {
	if timeoutSec <= 0 {
		timeoutSec = 120
	}
	return &shellTool{root: root, timeoutSec: timeoutSec, mgr: mgr, sb: sb}
}

func (t *shellTool) Name() string                { return "shell" }
func (t *shellTool) Capability() tool.Capability { return tool.CapExecute }

// CapabilityFor implements tool.CapabilityOverrider (P25.4c): a narrow
// allowlist of read-only commands (ls, cat, git status/log/diff, …) whose
// arguments stay within root (P32.1) is gated as CapRead instead of the
// tool's usual CapExecute, so it no longer needs a full execute approval in
// build mode and is allowed outright (not silently denied) under the
// plan-mode read gate. The static Capability() above is unchanged and still
// governs anything readOnlyShellCommand doesn't recognize as safe — which
// now includes any command reading outside the workspace root, so it falls
// back to requiring the normal execute approval instead of being silently
// auto-allowed. CapabilityOverrider carries no context, so this uses the
// tool's construction-time root rather than a session-scoped override.
func (t *shellTool) CapabilityFor(input json.RawMessage) tool.Capability {
	var args struct {
		Command string `json:"command"`
	}
	if json.Unmarshal(input, &args) == nil && readOnlyShellCommand(t.root, args.Command) {
		return tool.CapRead
	}
	return tool.CapExecute
}
func (t *shellTool) Description() string {
	if runtime.GOOS == "windows" {
		return "Run a PowerShell command in the workspace directory and return combined stdout/stderr. Commands execute via: powershell -NoProfile -NonInteractive -Command <command>. Use PowerShell syntax — Unix commands (ls, cat, grep, find, rm, chmod, etc.) are not available; use Get-ChildItem, Get-Content, Select-String, Remove-Item, etc."
	}
	return "Run a shell command in the workspace directory and return combined stdout/stderr. Commands execute via /bin/sh -c. Bounded by a configurable timeout."
}
func (t *shellTool) InputSchema() json.RawMessage {
	if runtime.GOOS == "windows" {
		return schema(`{"type":"object","properties":{"command":{"type":"string","description":"PowerShell command to run. Use PowerShell syntax (Get-ChildItem, Get-Content, Select-String, Remove-Item, etc.) — Unix commands do not work in PowerShell."},"timeout_sec":{"type":"integer","description":"optional per-call timeout override in seconds"},"background":{"type":"boolean","description":"run as a detached background job and return a task id immediately instead of blocking"}},"required":["command"]}`)
	}
	return schema(`{"type":"object","properties":{"command":{"type":"string","description":"the shell command to run via /bin/sh -c"},"timeout_sec":{"type":"integer","description":"optional per-call timeout override in seconds"},"background":{"type":"boolean","description":"run as a detached background job and return a task id immediately instead of blocking"}},"required":["command"]}`)
}

func (t *shellTool) OutputSchema() json.RawMessage {
	return schema(`{"type":"object","properties":{"output":{"type":"string","description":"combined stdout and stderr"},"exit_code":{"type":"integer"}},"required":["output","exit_code"]}`)
}

func (t *shellTool) Execute(ctx context.Context, input json.RawMessage) (tool.Result, error) {
	var args struct {
		Command    string `json:"command"`
		TimeoutSec int    `json:"timeout_sec"`
		Background bool   `json:"background"`
	}
	if err := parseArgs(input, &args); err != nil {
		return tool.Result{}, err
	}
	if strings.TrimSpace(args.Command) == "" {
		return tool.Result{Content: "command is required", IsError: true}, nil
	}

	const maxTimeoutSec = 600
	timeout := time.Duration(t.timeoutSec) * time.Second
	if args.TimeoutSec > 0 {
		timeout = time.Duration(min(args.TimeoutSec, maxTimeoutSec)) * time.Second
	}
	root := effectiveRoot(ctx, t.root)

	if args.Background {
		if t.mgr == nil {
			return tool.Result{Content: "background jobs are not available in this context", IsError: true}, nil
		}
		tk, err := t.mgr.Start(task.Spec{Kind: "shell", Title: truncateTitle(args.Command)}, func(jobCtx context.Context, emit func(string)) (string, error) {
			return "", t.execStreaming(jobCtx, root, args.Command, timeout, emit)
		})
		if err != nil {
			return tool.Result{Content: "shell: " + err.Error(), IsError: true}, nil
		}
		return tool.Result{Content: fmt.Sprintf("Started background shell job (task id %s). Poll with task_get; read output with task_output; cancel with task_stop.", tk.ID)}, nil
	}

	// Foreground execution. A command not classified read-only might write
	// files directly (bypassing write_file/edit_file's own checkpoint
	// capture), so bracket it with best-effort git-status-based capture —
	// see shell_checkpoint.go — unless the command is already known safe.
	var text string
	var err error
	if readOnlyShellCommand(root, args.Command) {
		text, err = t.exec(ctx, root, args.Command, timeout)
	} else {
		text, err = captureShellWrites(ctx, checkpoint.SnapshotterFrom(ctx), root, func() (string, error) {
			return t.exec(ctx, root, args.Command, timeout)
		})
	}
	const maxOutput = 200 << 10 // 200 KiB — prevent context flooding on large outputs
	if len(text) > maxOutput {
		text = text[:maxOutput] + fmt.Sprintf("\n[...%d bytes truncated — use background:true and task_output for large commands]", len(text)-maxOutput)
	}
	if err != nil {
		content := fmt.Sprintf("%v\n%s", err, text)
		if hint := interpreterHint(args.Command); hint != "" {
			content += "\n" + hint
		}
		return tool.Result{Content: content, IsError: true}, nil
	}
	return tool.Result{Content: text}, nil
}

// scriptExtInterpreters maps a scripting file extension to the interpreter
// commonly used to run it, for interpreterHint's suggestion (P39.2).
var scriptExtInterpreters = map[string]string{
	".py": "python", ".sh": "sh", ".js": "node", ".rb": "ruby",
}

// knownInterpreterPrefixes are first-token values that already indicate the
// command runs through an interpreter, so no hint is needed.
var knownInterpreterPrefixes = []string{"python", "python3", "bash", "sh", "node", "ruby"}

// interpreterHint returns a "did you mean to run this with an interpreter"
// suggestion when command's first token looks like a bare script path with a
// known scripting extension and isn't already prefixed by a known
// interpreter, or "" otherwise. Small local models were observed in live
// testing (P38.1) invoking a bare script path (e.g. `recon.py`) as if it were
// an executable, which fails differently on Windows (no shebang support)
// than Unix. This only appends a hint on the failure path — it never blocks
// or rewrites the command pre-execution, so the shell tool stays permissive.
func interpreterHint(command string) string {
	fields := strings.Fields(command)
	if len(fields) == 0 {
		return ""
	}
	first := fields[0]
	for _, p := range knownInterpreterPrefixes {
		if strings.EqualFold(first, p) {
			return ""
		}
	}
	interp, ok := scriptExtInterpreters[strings.ToLower(filepath.Ext(first))]
	if !ok {
		return ""
	}
	return fmt.Sprintf("(did you mean to run this with an interpreter, e.g. `%s %s`?)", interp, first)
}

// exec runs a command synchronously, delegating to the sandbox backend if set.
func (t *shellTool) exec(ctx context.Context, root, command string, timeout time.Duration) (string, error) {
	if t.sb != nil {
		return t.sb.Exec(ctx, command, sandbox.ExecOpts{Dir: root, Timeout: timeout})
	}
	return sandbox.NewLocalBackend().Exec(ctx, command, sandbox.ExecOpts{Dir: root, Timeout: timeout})
}

// execStreaming runs a command with streaming output.
func (t *shellTool) execStreaming(ctx context.Context, root, command string, timeout time.Duration, emit func(string)) error {
	if t.sb != nil {
		return t.sb.ExecStreaming(ctx, command, sandbox.ExecOpts{Dir: root, Timeout: timeout}, emit)
	}
	return sandbox.NewLocalBackend().ExecStreaming(ctx, command, sandbox.ExecOpts{Dir: root, Timeout: timeout}, emit)
}
