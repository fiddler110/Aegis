package tui

// commandDef is the single source of truth for one built-in slash command.
// The dispatch table (d.builtins), the general /help listing, /help <name>'s
// detailed text, and the completion-popup/command-palette entry all derive
// from commandDefs instead of three separately hand-maintained lists (P14.10)
// — the structural fix for the drift class that let /security-config, /scan,
// /debate, /rollback, /detach, /archive, and /humor silently fall out of the
// completion popup while still being fully dispatchable (P14.1). Any future
// built-in command should be added here once; it then automatically appears
// everywhere it needs to.
type commandDef struct {
	name    string // dispatch key, e.g. "mode"
	argHint string // shown after the name in /help's general listing, e.g. "<plan|build|auto>"

	// shortDesc is the one-line description shared by /help's general listing
	// and the completion popup/palette.
	shortDesc string

	// detailedHelp is the full text for /help <name>.
	detailedHelp string

	// needsArgs completes the command with a trailing space in the popup so
	// the user can type arguments immediately, rather than accepting the bare
	// command. "persona" is deliberately absent (needsArgs: false): Tab/Enter
	// on /persona dispatches it immediately, which opens the interactive
	// picker.
	needsArgs bool

	// transient marks a purely informational command whose Output is rendered
	// in a dismissable overlay panel (P33.11) instead of appended to the
	// transcript, so a session of housekeeping (/status, /help, /memory …)
	// doesn't litter the conversation with stale blocks. Only set it for
	// read-only commands with no action variant: a command that also writes
	// config or toggles session state (e.g. /sandbox, /skills, /guard) must
	// keep its confirmation in the transcript, and since the flag is per
	// command — not per invocation — such dual-purpose commands stay
	// non-transient. The dispatcher stamps SlashResult.Transient from this flag
	// (NewSlashDispatcher), keeping the decision in this single-source table
	// rather than at scattered call sites.
	transient bool

	handler func(*SlashDispatcher, []string) SlashResult
}

// commandDefs is the ordered list of every built-in slash command except
// "quit" — a bare alias for "exit" registered separately in
// NewSlashDispatcher so it isn't listed twice (matching the prior behavior
// documented in help_test.go and completion_test.go).
//
// This is a function rather than a package-level var: several handlers
// (e.g. cmdHelp) range over the command list, and a var initializer that
// references those same handler values would create a compile-time
// initialization cycle (var commandDefs -> handler funcs -> commandDefs).
func commandDefs() []commandDef {
	return []commandDef{
		{
			name: "help", argHint: "[cmd]", needsArgs: true, transient: true,
			shortDesc:    "Show this help or detail for a command",
			detailedHelp: "/help [command]\n  Show available commands, or detailed help for a specific command.\n  No args: also lists keyboard shortcuts, including keybind-only features that have no slash-command equivalent (e.g. ctrl+x terminal pane, ctrl+t sub-agent list, ctrl+y session switcher, ctrl+r input-history search).",
			handler:      (*SlashDispatcher).cmdHelp,
		},
		{
			name: "persona", argHint: "[name]",
			shortDesc:    "Pick persona interactively, or switch directly by name",
			detailedHelp: "/persona [name]\n  No args: open an interactive list to pick a persona.\n  With name: switch directly, e.g. /persona security.",
			handler:      (*SlashDispatcher).cmdPersona,
		},
		{
			name: "mode", argHint: "<plan|build|auto>", needsArgs: true,
			shortDesc:    "Switch permission mode",
			detailedHelp: "/mode <plan|build|auto>\n  Switch the permission mode for the current session.\n  plan = read-only\n  build = file edits allowed, shell execution requires approval\n  auto  = all capabilities allowed without prompting",
			handler:      (*SlashDispatcher).cmdMode,
		},
		{
			name: "guard", argHint: "[on|off|status]", needsArgs: true,
			shortDesc:    "Toggle output validation for this session",
			detailedHelp: "/guard [on|off|status]\n  Toggle output validation for the current session.\n  Defaults to the configured output_guard.enabled; resets on restart.",
			handler:      (*SlashDispatcher).cmdGuard,
		},
		{
			name: "tools", argHint: "<compact|full>", needsArgs: true,
			shortDesc:    "Set tool-output line cap (compact=10 lines, full=unlimited)",
			detailedHelp: "/tools <compact|full>\n  compact: cap multi-line tool output at 10 lines (default).\n  full: show complete tool output without truncation.\n  Applies to new results; toggle resets on TUI restart.",
			handler:      (*SlashDispatcher).cmdTools,
		},
		{
			name:         "clear",
			shortDesc:    "Clear the transcript",
			detailedHelp: "/clear\n  Clear the conversation transcript (session history is preserved).",
			handler:      (*SlashDispatcher).cmdClear,
		},
		{
			name:         "config",
			shortDesc:    "Interactive configuration wizard",
			detailedHelp: "/config\n  Open the interactive configuration wizard to change provider, model, tokens, and think settings.\n  Changes are written to the global config file and take effect on next restart.",
			handler:      (*SlashDispatcher).cmdConfig,
		},
		{
			name: "memory", transient: true,
			shortDesc:    "Show saved memories",
			detailedHelp: "/memory\n  Display saved project and user memory entries.",
			handler:      (*SlashDispatcher).cmdMemory,
		},
		{
			name: "remember", argHint: "<text>", needsArgs: true,
			shortDesc:    "Save a memory entry",
			detailedHelp: "/remember <text>\n  Save a fact to project memory for future sessions.",
			handler:      (*SlashDispatcher).cmdRemember,
		},
		{
			name:         "compact",
			shortDesc:    "Force context compaction now, ahead of a heavy stretch",
			detailedHelp: "/compact\n  Force conversation compaction now instead of waiting for the automatic budget-driven trigger — summarizes older turns into a compact note, keeping the most recent messages verbatim.\n  Useful ahead of a long tool-heavy stretch you know is coming. Reports \"nothing to compact\" if the conversation is too short to safely summarize.\n  Not to be confused with /tools compact, which sets the tool-output display width and does not touch the conversation.",
			handler:      (*SlashDispatcher).cmdCompact,
		},
		{
			name: "skills", argHint: "[enable|disable <name> [global]]",
			shortDesc: "List skills, or toggle a built-in skill on/off",
			detailedHelp: "/skills\n  List active skills (project/user skill files, plus any enabled built-ins) and the full built-in catalog with on/off status.\n" +
				"/skills enable <name> [global]\n  Turn on a built-in skill shipped with Aegis. Writes to the project config (.aegis/config.yaml) by default; add 'global' to write to the user config instead. Takes effect on restart.\n" +
				"/skills disable <name> [global]\n  Turn off a built-in skill the same way.",
			handler: (*SlashDispatcher).cmdSkills,
		},
		{
			name: "commands", transient: true,
			shortDesc:    "List custom commands",
			detailedHelp: "/commands\n  List custom user-defined commands from .aegis/commands/.",
			handler:      (*SlashDispatcher).cmdCommands,
		},
		{
			name:         "models",
			shortDesc:    "Interactively pick a model, grouped by provider (current one marked)",
			detailedHelp: "/models\n  Open an interactive picker of curated models grouped by provider, with the session's current model marked. Selecting one is equivalent to running /model <id>.\n  Use /model <id> directly if you already know the exact id, or /model with no args to print the current model without opening the picker.",
			handler:      (*SlashDispatcher).cmdModels,
		},
		{
			name: "model", argHint: "<model-id|default>", needsArgs: true,
			shortDesc:    "Switch this session's model mid-session",
			detailedHelp: "/model <model-id>\n  Switch this session's model. Persisted as a per-session override that outranks the active persona's own model and the global default on every subsequent turn.\n  Must be an id for your currently configured provider (see /status) — a cross-provider id fails on the next turn, not at switch time.\n  /model default: clear the override, reverting to the persona/global default.\n  No args: show the current model.",
			handler:      (*SlashDispatcher).cmdModel,
		},
		{
			name: "status", transient: true,
			shortDesc:    "Show daemon health, sandbox backend, and cost caps/spend",
			detailedHelp: "/status\n  Show daemon reachability, provider/model, active sandbox backend and any fallback reason, this session's cumulative spend against its caps, and cross-session today's spend against the daily caps.",
			handler:      (*SlashDispatcher).cmdStatus,
		},
		{
			name: "sandbox", argHint: "[use <target>]",
			shortDesc:    "Show or switch the shell-execution sandbox",
			detailedHelp: "/sandbox [use <target>]\n  No args: show the configured sandbox backend and detected container runtimes (docker, podman, wslc, container).\n  use <local|auto|docker|podman|wslc|container>: set the backend (written to global config; takes effect on restart).",
			handler:      (*SlashDispatcher).cmdSandbox,
		},
		{
			name: "security", argHint: "[status|install <tool>|baseline [path]|config [global]]",
			shortDesc:    "Show scanner status, manage the suppression baseline, or install/configure scanners",
			detailedHelp: "/security [status|install <tool>|baseline [path]|config [global]]\n  No args or 'status': show how each security scanner would run right now (host binary, container fallback, or unavailable and why) — same as `aegis security status`.\n  'install <tool> [confirm]': show the guided host-install command for a scanner; add 'confirm' to actually run it (never runs without the explicit confirm word) — same as `aegis security install`.\n  'baseline [path]': show the accepted-risk suppression baseline (.aegis/security-baseline.yaml) and each entry's active/expired/invalid status — same as `aegis security baseline`.\n  'config [global]': open the interactive /security-config dialog (see /help security-config).",
			handler:      (*SlashDispatcher).cmdSecurity,
		},
		{
			name: "security-config", argHint: "[global]", needsArgs: true,
			shortDesc:    "Interactively configure, enable, and install security scanners",
			detailedHelp: "/security-config [global]\n  Opens an interactive dialog to configure the security scanners (opengrep, gosec, bandit, brakeman, njsscan, trivy, gitleaks, trufflehog, kubescape, hadolint, grype, dockle, osv-scanner, syft) used by /scan and the security_scan tool: toggle enabled (including the opt-in language-specific SAST engines), pick host/container/auto, set the install policy, and set a digest-pinned container image. trufflehog additionally offers a warning-labelled \"verify\" toggle for live credential verification (host-only). Selecting a tool now also offers \"Install now (guided)\" — shows the exact host command and runs it after you confirm, no separate CLI trip required.\n  No args: edits the project's .aegis/config.yaml. 'global': edits ~/.config/aegis/config.yaml instead.\n  Written immediately; restart Aegis to apply.",
			handler:      (*SlashDispatcher).cmdSecurityConfig,
		},
		{
			name: "scan", argHint: "[path|scanner[,scanner...] [path]|list|image <ref>|sbom [path]|network <target...>]", needsArgs: true,
			shortDesc:    "Run security scanners now and print the findings report",
			detailedHelp: "/scan [path|scanner[,scanner...] [path]|list|image <ref>|sbom [path]|network <target...>]\n  Runs the security scanners directly and prints the findings report — no model turn spent, same scan `aegis scan`/the security_scan tool runs. Every findings report is also persisted under .aegis/security/ (scan.json, image.json, or network.json).\n  No args: scan the whole workspace with every enabled scanner, auto-detecting the project's language (go.mod/*.go, requirements.txt/*.py, Gemfile/*.rb, package.json/*.js) to auto-enable the matching opt-in SAST engine (gosec/bandit/brakeman/njsscan) for this run.\n  /scan <path>: scan just a workspace-relative subdirectory (same language auto-detection, scoped to that path).\n  /scan <scanner-or-category>[,<...>] [path]: run only the named scanner(s), force-enabled regardless of config — e.g. /scan trufflehog, /scan secrets, /scan gitleaks,trufflehog src/. Categories: secrets, sast, sca/deps, iac, misconfig.\n  /scan list: list every valid scanner name and category alias, with live availability (on PATH / container / unavailable) and whether it runs by default — the reference for the selector argument above.\n  /scan image <ref>: scan a container image reference instead (e.g. /scan image alpine:3.20).\n  /scan sbom [path]: generate a CycloneDX SBOM instead of a findings report.\n  /scan network <target> [target...]: run nmap+nuclei (recon_scan) against a bare host/IP/CIDR list — same shared security.dast.allowed_targets gate as /scan and dast_scan; a disallowed target is rejected before either scanner runs.\n  Use /security-config first to enable/install the scanners you want included.",
			handler:      (*SlashDispatcher).cmdScan,
		},
		{
			name: "knowledge", argHint: "[index|query <text>]", needsArgs: true,
			shortDesc:    "Rebuild or search the project knowledge base",
			detailedHelp: "/knowledge [index|query <text>]\n  index: rebuild the project knowledge base FTS5 index — same as `aegis knowledge index`.\n  query <text>: search the index — same as the model's project_knowledge tool.\n  Runs directly against the daemon's own store, no model turn spent.",
			handler:      (*SlashDispatcher).cmdKnowledge,
		},
		{
			name:         "index",
			shortDesc:    "Rebuild the repository map for the system prompt",
			detailedHelp: "/index\n  Rebuild the compact repository map (top-level symbols per file) and refresh it in the daemon's system prompt — same build as `aegis index`, no restart needed.",
			handler:      (*SlashDispatcher).cmdIndex,
		},
		{
			name: "debate", argHint: "[--domain generic] [--file <path>]... <claim>", needsArgs: true,
			shortDesc:    "Adversarially debate any claim (propose/critique/rebut/arbitrate) and print the verdict",
			detailedHelp: "/debate [--domain generic] [--file <path>]... [--proposer|--critic|--arbiter <persona>] [--max-rounds <n>] <claim>\n  Runs a multi-agent debate directly against the daemon's configured model — a critic challenges the claim (grounded in cited evidence or an explicit CONCEDE), the proposer rebuts, this repeats for up to 2 rounds (or --max-rounds), then an arbiter issues a final UPHOLD/REVISE/REJECT verdict with a confidence label. Unlike /scan, this does spend model turns (one per role per round) since the debate itself is model-driven.\n  Defaults to the security-researcher/security-critic/security-arbiter personas; pass --domain generic to use general/critic/arbiter instead for non-security claims (documents, plans, decisions). --file points the roles at specific files to read for grounding instead of relying on recall — useful for debating the accuracy of a document or implementation plan. --proposer/--critic/--arbiter override individual role personas regardless of --domain.\n  Same underlying mechanism as the `agent` tool's mode:\"debate\", exposed to run directly on a claim you already have in hand without a conversational turn first.",
			handler:      (*SlashDispatcher).cmdDebate,
		},
		{
			name: "threat-model", argHint: "[framework] [system or feature]",
			shortDesc:    "Threat-model a system or feature (STRIDE/LINDDUN/PASTA/Trike/VAST/NIST 800-154)",
			detailedHelp: "/threat-model [framework] [system or feature]\n  Loads the threat-modeling skill and starts a threat model. If the first word is a recognized framework (stride, linddun, pasta, trike, vast, or nist/nist-800-154, case-insensitive) it's used directly; otherwise a picker dialog opens with all six frameworks and a one-line description of each, forcing the choice up front instead of spending a model turn asking in chat.\n  No args: opens the framework picker, then threat-models the application/codebase in the current workspace (named explicitly, with its path) — the common case, since that's almost always what's actually being modeled.\n  Framework only, e.g. /threat-model PASTA: same whole-workspace scope with that framework, no picker.\n  Framework + scope, e.g. /threat-model PASTA the auth service: scopes to the named system/feature within the workspace, no picker.\n  Scope only (no recognized framework as the first word), e.g. /threat-model the auth service: opens the picker, then scopes to that system/feature.\n  Spends a model turn once a framework is set (picker selection is free), same as /debate — a discoverable entry point into the skill instead of relying on the model noticing a trigger phrase in free text.",
			handler:      (*SlashDispatcher).cmdThreatModel,
		},
		{
			name: "report", argHint: "[latex] <sources…>", needsArgs: true,
			shortDesc:    "Consolidate markdown docs into a report (html or latex/PDF)",
			detailedHelp: "/report [latex] <sources…>\n  Loads a report-consolidation skill and starts writing. Names the source markdown docs (files, globs, or a directory) to synthesize into one coherent report.\n  No 'latex': loads the html-report skill — a single self-contained, shareable .html file.\n  With 'latex': loads the latex-report skill instead — a formally structured LaTeX document built via latex_new_document/latex_build, output as PDF.\n  e.g. /report research/*.md  or  /report latex research/roadmap.md research/releases.md\n  Spends a model turn, same as /debate and /threat-model — a discoverable entry point instead of relying on the model noticing a trigger phrase in free text.",
			handler:      (*SlashDispatcher).cmdReport,
		},
		{
			name: "research", argHint: "[topic or question]",
			shortDesc:    "Deep-research a topic on the web: planned rounds, vetted sources, cited report",
			detailedHelp: "/research [topic or question]\n  Loads the deep-research skill and starts a structured research run: iterative plan → search → read → synthesize rounds (capped at 8), a source-quality bar on what gets cited, a findings log with an analyzed-URLs audit trail, and a final report with numbered citations.\n  No args: asks what to research.\n  With args: researches the given topic, e.g. /research current state of Go structured logging libraries.\n  Needs the deep-research built-in skill enabled (/skills enable deep-research) and spends model turns, same as /debate, /threat-model, and /report — a discoverable entry point into the skill instead of relying on the model noticing a trigger phrase in free text.",
			handler:      (*SlashDispatcher).cmdResearch,
		},
		{
			name: "session", argHint: "[list]", needsArgs: true, transient: true,
			shortDesc:    "Show session info or list sessions",
			detailedHelp: "/session [list]\n  No args: show current session info.\n  list: show all sessions.",
			handler:      (*SlashDispatcher).cmdSession,
		},
		{
			name: "rewind", argHint: "[n] [scope]", needsArgs: true,
			shortDesc:    "List or restore checkpoints (code/conversation/both)",
			detailedHelp: "/rewind [n] [code|conversation|both]\n  No args: list checkpoints (rewind points) for this session, newest first.\n  /rewind <n>: restore checkpoint n (both files and conversation by default).\n  Scope: 'code' restores only files, 'conversation' only the transcript, 'both' (default) does both.\n  Each checkpoint is the state just before a user turn; rewinding undoes that turn's file changes and/or messages.",
			handler:      (*SlashDispatcher).cmdRewind,
		},
		{
			name: "rollback", argHint: "[n]", needsArgs: true,
			shortDesc:    "Restore checkpoint n and run git reset --hard to pre-turn HEAD",
			detailedHelp: "/rollback [n]\n  No args: list checkpoints (rollback points) for this session, newest first.\n  /rollback <n>: restore checkpoint n's conversation AND run `git reset --hard` to that checkpoint's commit — a harder reset than /rewind's 'both' scope, which restores files by rewriting them rather than resetting git history.\n  Use this when a turn's file changes need to be fully undone at the git level, not just reverted in the working tree.",
			handler:      (*SlashDispatcher).cmdRollback,
		},
		{
			name: "fork", argHint: "[n]", needsArgs: true,
			shortDesc:    "Branch into a new session, optionally from checkpoint n",
			detailedHelp: "/fork [n]\n  No args: fork the conversation as-is into a brand-new session at its current end — a clean sandbox to try something risky without touching this session.\n  /fork <n>: fork truncated to checkpoint n (newest first, same numbering as /rewind) — the state just before that turn's user message, ready for a fresh/edited message picking up from there.\n  Unlike /rewind, the source session is never modified; the TUI switches into the new forked session on success.\n  See also: pressing Esc twice with an empty input box (and not streaming) opens an interactive picker that forks at a chosen prior message and pre-fills it for editing.",
			handler:      (*SlashDispatcher).cmdFork,
		},
		{
			name: "side", argHint: "<question>", needsArgs: true,
			shortDesc:    "Ask a quick, unrelated question in a fresh throwaway session",
			detailedHelp: "/side <question>\n  Runs the question through a brand-new, isolated session — no shared history with the current conversation — and prints the answer inline once it comes back.\n  The main session's messages, token/cost accounting, and on-screen view are completely untouched; nothing here counts against this conversation's context.\n  Always runs read-only (plan mode) with the default persona, regardless of the current session's mode/persona/model.\n  The side session is kept (not deleted) so the Q&A isn't lost — titled \"[side] ...\" so it's easy to spot and prune later via /session list or `aegis sessions delete`.\n  Blocks while the answer is generated, same as /debate.",
			handler:      (*SlashDispatcher).cmdSide,
		},
		{
			name: "detach", argHint: "[on|off]", needsArgs: true,
			shortDesc:    "Run this session in the background (turn continues after TUI closes)",
			detailedHelp: "/detach [on|off]\n  Toggle background (detached) mode for this session.\n  on (default): turns continue running after the TUI closes. Use `aegis bg events <id>` to check progress.\n  off: revert to normal foreground execution.",
			handler:      (*SlashDispatcher).cmdDetach,
		},
		{
			name: "humor", argHint: "[on|off]", needsArgs: true,
			shortDesc:    "Toggle D&D-themed thinking phrases in the response area",
			detailedHelp: "/humor [on|off]\n  Toggle D&D-themed thinking phrases in the response area.\n  on: show phrases like \"Rolling for Initiative\", \"Consulting the Tome\", etc.\n  off: show plain \"thinking…\" status.\n  No args: toggle current state.\n  Set tui.humor_mode in your config file to make this permanent.",
			handler:      (*SlashDispatcher).cmdHumor,
		},
		{
			name: "archive", argHint: "[off|list]", needsArgs: true,
			shortDesc:    "Archive this session (hidden from listings; data kept). /archive off to restore",
			detailedHelp: "/archive [off|list]\n  Archive the current session — it is hidden from normal session listings but all data is preserved.\n  /archive off: restore an archived session to active status.\n  /archive list: list all archived sessions.\n  To permanently remove a session, use `aegis sessions delete <id>` from the CLI.",
			handler:      (*SlashDispatcher).cmdArchive,
		},
		{
			name: "prune", argHint: "[days]", needsArgs: true,
			shortDesc:    "Delete non-archived sessions older than N days",
			detailedHelp: "/prune [days]\n  Delete non-archived sessions not updated in the last N days.\n  No args: use the server's configured TTL.\n  Same operation as `aegis sessions prune`.",
			handler:      (*SlashDispatcher).cmdPrune,
		},
		{
			name: "bundle", argHint: "[install|info <path-or-url>]", needsArgs: true,
			shortDesc:    "Install or inspect a persona/skill/command bundle",
			detailedHelp: "/bundle [install|info <path-or-url>]\n  'info <path-or-url>': show a bundle's manifest, artifacts, and content hash — same as `aegis bundle info`. A git URL (https/git@/ssh) is shallow-cloned to a temp dir first.\n  'install <path-or-url> [global] [sha256:<hash>] [confirm]': install a bundle's commands/agents/skills. No 'confirm': preview only (manifest, artifacts, target scope, hash) — nothing is written. 'global' installs into the user data dir instead of the project's .aegis/ (default). 'sha256:<hash>' pins the P7.6 content-hash provenance check (see /bundle info) and aborts if it doesn't match — same as the CLI's --expect-sha256.\n  Same underlying package as `aegis bundle install/info`.",
			handler:      (*SlashDispatcher).cmdBundle,
		},
		{
			name: "runs", transient: true,
			shortDesc:    "List message runs currently in flight across all sessions",
			detailedHelp: "/runs\n  List message runs currently in flight across all sessions (session id, elapsed time, tool-call count, last event kind, title) — same data as `aegis runs`.",
			handler:      (*SlashDispatcher).cmdRuns,
		},
		{
			name: "bg", argHint: "[list|events [session-id]]", transient: true,
			shortDesc:    "List background (detached) sessions, or print one's buffered events",
			detailedHelp: "/bg [list|events [session-id]]\n  No args or 'list': list sessions currently running in background (detached) mode.\n  'events [session-id]': print buffered engine events from a background session (defaults to the current session) — same data as `aegis bg events`.",
			handler:      (*SlashDispatcher).cmdBG,
		},
		{
			name:         "timeline",
			shortDesc:    "Jump to a past turn in the conversation timeline",
			detailedHelp: "/timeline\n  Opens an interactive picker of past turns in this conversation. Selecting one jumps the transcript view to that point — a navigation aid, not a rewind (use /rewind or /rollback to actually restore state).",
			handler:      (*SlashDispatcher).cmdTimeline,
		},
		{
			name:         "sidebar",
			shortDesc:    "Toggle the sidebar panel on/off (also ctrl+b)",
			detailedHelp: "/sidebar\n  Toggles the sidebar panel (context %, cost, agent count) on/off. Same as pressing ctrl+b. Hidden by default; folds into the status bar when off.",
			handler:      (*SlashDispatcher).cmdSidebar,
		},
		{
			name: "scrollback", argHint: "[on|off]", needsArgs: true,
			shortDesc:    "Toggle raw scrollback mode: plain text, native terminal scroll/select/search",
			detailedHelp: "/scrollback [on|off]\n  Toggle raw scrollback mode (P22.6).\n  on: renders the transcript as plain sequential text with nothing clipped, and releases the terminal's alt-screen buffer and mouse capture — your terminal emulator's own scrollback, mouse-wheel scrolling, click-drag selection, and search (e.g. ctrl+shift+f) all work natively again, the way they would against plain stdout.\n  off (default): the normal dashboard — bounded transcript viewport, sidebar, in-app mouse-drag selection (drag to copy) — is restored.\n  No args: toggle current state.\n  Sidebar, scrollbar, and the terminal pane (ctrl+x) are hidden while this is on, since they assume a fixed-height dashboard. This session only; resets on restart.",
			handler:      (*SlashDispatcher).cmdScrollback,
		},
		{
			name: "theme", argHint: "<name>", needsArgs: true,
			shortDesc:    "Switch the color scheme live, no restart needed",
			detailedHelp: "/theme <name>\n  Switch the TUI color scheme immediately — no restart needed.\n  Built in: dark, light, catppuccin, dracula, gruvbox, tokyonight.\n  Custom: drop a <name>.json file (background/foreground + the 16 ANSI colors) in .aegis/themes/ (project) or ~/.aegis/themes/ (user).\n  No args: show the current theme.\n  This session only; set tui.theme: <name> in config (project or global) to make it the default on restart.",
			handler:      (*SlashDispatcher).cmdTheme,
		},
		{
			name: "notify", argHint: "<off|bell|desktop|both>", needsArgs: true,
			shortDesc:    "Set the attention-system mode (bell/desktop notifications)",
			detailedHelp: "/notify <off|bell|desktop|both>\n  Set how the P16.1 attention system fires on stream-end, approval-pending, and error while the terminal isn't focused.\n  off: nothing. bell: terminal BEL. desktop: OSC 9/777 desktop notification. both (default): bell + desktop.\n  No args: show the current mode.\n  This session only; set tui.notifications: <mode> in config (project or global) to make it the default on restart.",
			handler:      (*SlashDispatcher).cmdNotify,
		},
		{
			name: "diff", argHint: "[--staged] [path]",
			shortDesc:    "Show the working-tree git diff, including untracked files",
			detailedHelp: "/diff [--staged] [path]\n  Shows the working-tree git diff as a syntax-highlighted transcript block — no model turn spent, same no-model-turn pattern as /scan.\n  No args: tracked changes (staged + unstaged) against HEAD, plus a synthetic \"new file\" diff for each untracked file (plain `git diff` omits those).\n  --staged (or --cached): only the staged (index) diff; untracked files are excluded since they can't be staged without adding them first.\n  <path>: scope to a workspace-relative file or directory.",
			handler:      (*SlashDispatcher).cmdDiff,
		},
		{
			name: "review", argHint: "[--staged | <branch|commit>]",
			shortDesc:    "Read-only review of a diff, with structured findings",
			detailedHelp: "/review [--staged | <branch|commit>]\n  Reviews a diff for correctness/quality/security issues, seeded with the content-review skill's severity-rubric format. Spends a model turn, unlike /diff.\n  No args: the uncommitted working-tree changes (tracked + untracked), same scope as /diff's default.\n  --staged (or --cached): only the staged (index) changes.\n  <branch>: diff against the merge-base with that branch (\"what would this PR change\").\n  <commit>: that single commit's own diff.\n  Switches the session to plan (read-only) mode for the review if it isn't already, and says so — /mode <prev> to switch back afterward.\n  Needs the content-review built-in skill enabled (/skills enable content-review) for the structured format; without it the model still reviews the diff, just less structured.",
			handler:      (*SlashDispatcher).cmdReview,
		},
		{
			name: "copy", argHint: "[N]",
			shortDesc:    "Copy last assistant message, or Nth code block, to clipboard",
			detailedHelp: "/copy [N]\n  No args: copy the last assistant message to the clipboard.\n  /copy <N>: copy the Nth fenced code block from the last assistant message instead.\n  Uses pbcopy/xclip/clip.exe depending on platform; shows a toast confirming what was copied.",
			handler:      (*SlashDispatcher).cmdCopy,
		},
		{
			name: "share", argHint: "[html|md|json]", needsArgs: true,
			shortDesc:    "Export this session to a shareable transcript file",
			detailedHelp: "/share [html|md|json]\n  Export this session as a shareable transcript file in the current directory.\n  html (default): a self-contained page with styling and inline images.\n  md: Markdown. json: the raw session.\n  Use `aegis sessions export <id>` for the same from the CLI.",
			handler:      (*SlashDispatcher).cmdShare,
		},
		{
			name:         "paste-image",
			shortDesc:    "Attach an image from the OS clipboard (also ctrl+v)",
			detailedHelp: "/paste-image\n  Read an image directly off the OS clipboard (not a pasted file path) and attach it to the draft — same as pressing ctrl+v. Useful when the terminal itself intercepts ctrl+v for its own paste binding.\n  Windows/macOS/Linux clipboard access differs: macOS requires pngpaste (brew install pngpaste), Linux requires wl-clipboard or xclip.",
			handler:      (*SlashDispatcher).cmdPasteImage,
		},
		{
			name:         "exit",
			shortDesc:    "Exit Aegis",
			detailedHelp: "/quit\n  Exit Aegis.",
			handler:      (*SlashDispatcher).cmdQuit,
		},
	}
}
