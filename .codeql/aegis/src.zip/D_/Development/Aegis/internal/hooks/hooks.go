// Package hooks provides engine.Hooks implementations. The audit hook records
// every tool call to a JSONL trail, which doubles as a security audit log.
package hooks

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"sync"
	"time"
)

// Multi runs several hooks in order. PreToolUse stops at the first veto.
type Multi struct {
	hooks []Hook
}

// Hook is the local alias of the engine hook surface (kept here to avoid an
// import cycle; it matches engine.Hooks structurally).
type Hook interface {
	PreToolUse(ctx context.Context, toolName string, input json.RawMessage) error
	PostToolUse(ctx context.Context, toolName string, input json.RawMessage, result string, isError bool)
}

// NewMulti composes hooks.
func NewMulti(hs ...Hook) *Multi { return &Multi{hooks: hs} }

func (m *Multi) PreToolUse(ctx context.Context, name string, input json.RawMessage) error {
	for _, h := range m.hooks {
		if err := h.PreToolUse(ctx, name, input); err != nil {
			return err
		}
	}
	return nil
}

func (m *Multi) PostToolUse(ctx context.Context, name string, input json.RawMessage, result string, isErr bool) {
	for _, h := range m.hooks {
		h.PostToolUse(ctx, name, input, result, isErr)
	}
}

// Audit appends a JSONL record for each tool call to a file.
type Audit struct {
	mu   sync.Mutex
	path string
	file *os.File
}

// NewAudit creates an audit hook writing to path.
func NewAudit(path string) *Audit { return &Audit{path: path} }

// Close flushes and closes the audit file.
func (a *Audit) Close() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.file != nil {
		err := a.file.Close()
		a.file = nil
		return err
	}
	return nil
}

type auditRecord struct {
	Time    time.Time       `json:"time"`
	Phase   string          `json:"phase"`
	Tool    string          `json:"tool"`
	Input   json.RawMessage `json:"input,omitempty"`
	IsError bool            `json:"is_error,omitempty"`
	// Sub-agent lifecycle fields (phase "subagent_stop").
	AgentID string `json:"agent_id,omitempty"`
	Status  string `json:"status,omitempty"`
	Summary string `json:"summary,omitempty"`
	// Security policy fields (phase "policy_decision").
	Rule     string `json:"rule,omitempty"`
	Decision string `json:"decision,omitempty"`
	Reason   string `json:"reason,omitempty"`
	Cap      string `json:"cap,omitempty"`
}

// SubagentStop records the SUBAGENT_STOP lifecycle event for a finished teammate.
func (a *Audit) SubagentStop(agentID, status, summary string, isErr bool) {
	a.write(auditRecord{
		Time:    time.Now(),
		Phase:   "subagent_stop",
		AgentID: agentID,
		Status:  status,
		Summary: summary,
		IsError: isErr,
	})
}

// PolicyDecision records a contextual security policy decision.
func (a *Audit) PolicyDecision(toolName, cap, rule, decision, reason string) {
	a.write(auditRecord{
		Time:     time.Now(),
		Phase:    "policy_decision",
		Tool:     toolName,
		Cap:      cap,
		Rule:     rule,
		Decision: decision,
		Reason:   reason,
	})
}

// maxAuditInput is the maximum number of bytes recorded for a tool input in
// the audit log. Inputs larger than this are replaced with a size annotation
// to avoid logging bulk data or credentials embedded in long commands.
const maxAuditInput = 1024

func auditInput(input json.RawMessage) json.RawMessage {
	if len(input) <= maxAuditInput {
		return input
	}
	b, _ := json.Marshal(fmt.Sprintf("[%d bytes, truncated]", len(input)))
	return json.RawMessage(b)
}

func (a *Audit) PreToolUse(_ context.Context, name string, input json.RawMessage) error {
	a.write(auditRecord{Time: time.Now(), Phase: "pre", Tool: name, Input: auditInput(input)})
	return nil
}

func (a *Audit) PostToolUse(_ context.Context, name string, _ json.RawMessage, _ string, isErr bool) {
	a.write(auditRecord{Time: time.Now(), Phase: "post", Tool: name, IsError: isErr})
}

func (a *Audit) write(rec auditRecord) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.file == nil {
		f, err := os.OpenFile(a.path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
		if err != nil {
			slog.Error("audit: failed to open log", "path", a.path, "err", err)
			return
		}
		a.file = f
	}
	line, _ := json.Marshal(rec)
	if _, err := a.file.Write(append(line, '\n')); err != nil {
		slog.Error("audit: failed to write record", "path", a.path, "err", err)
	}
}
