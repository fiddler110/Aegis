package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strings"

	"github.com/fiddler110/aegis/internal/tool"
)

// mcpTool adapts an MCP server tool to the harness tool.Tool interface.
type mcpTool struct {
	client      *Client
	info        ToolInfo
	exposedName string
	capability  tool.Capability
	scanOutput  bool
	scanArgs    bool
	logger      *slog.Logger
}

func (t *mcpTool) Name() string                { return t.exposedName }
func (t *mcpTool) Description() string         { return t.info.Description }
func (t *mcpTool) Capability() tool.Capability { return t.capability }
func (t *mcpTool) InputSchema() json.RawMessage {
	if len(t.info.InputSchema) == 0 {
		return json.RawMessage(`{"type":"object"}`)
	}
	return t.info.InputSchema
}
func (t *mcpTool) Execute(ctx context.Context, input json.RawMessage) (tool.Result, error) {
	if t.scanArgs {
		warnOutboundSecrets(t.logger, t.client.Server(), t.info.Name, input)
	}
	text, isErr, err := t.client.CallTool(ctx, t.info.Name, input)
	if err != nil {
		return tool.Result{Content: fmt.Sprintf("mcp call failed: %v", err), IsError: true}, nil
	}
	return tool.Result{Content: wrapUntrusted(t.client.Server(), t.info.Name, text, t.scanOutput), IsError: isErr}, nil
}

// mcpResourceListTool lists available resources from an MCP server.
type mcpResourceListTool struct {
	client      *Client
	exposedName string
	capability  tool.Capability
}

func (t *mcpResourceListTool) Name() string { return t.exposedName }
func (t *mcpResourceListTool) Description() string {
	return "List available resources from the " + t.client.Server() + " MCP server"
}
func (t *mcpResourceListTool) Capability() tool.Capability { return t.capability }
func (t *mcpResourceListTool) InputSchema() json.RawMessage {
	return json.RawMessage(`{"type":"object","properties":{}}`)
}
func (t *mcpResourceListTool) Execute(ctx context.Context, _ json.RawMessage) (tool.Result, error) {
	resources, err := t.client.ListResources(ctx)
	if err != nil {
		return tool.Result{Content: fmt.Sprintf("list resources failed: %v", err), IsError: true}, nil
	}
	if len(resources) == 0 {
		return tool.Result{Content: "no resources available"}, nil
	}
	data, _ := json.Marshal(resources)
	return tool.Result{Content: string(data)}, nil
}

// mcpResourceReadTool reads a resource by URI from an MCP server.
type mcpResourceReadTool struct {
	client      *Client
	exposedName string
	capability  tool.Capability
	scanOutput  bool
	scanArgs    bool
	logger      *slog.Logger
}

func (t *mcpResourceReadTool) Name() string { return t.exposedName }
func (t *mcpResourceReadTool) Description() string {
	return "Read a resource by URI from the " + t.client.Server() + " MCP server"
}
func (t *mcpResourceReadTool) Capability() tool.Capability { return t.capability }
func (t *mcpResourceReadTool) InputSchema() json.RawMessage {
	return json.RawMessage(`{"type":"object","properties":{"uri":{"type":"string","description":"Resource URI to read"}},"required":["uri"]}`)
}
func (t *mcpResourceReadTool) Execute(ctx context.Context, input json.RawMessage) (tool.Result, error) {
	if t.scanArgs {
		warnOutboundSecrets(t.logger, t.client.Server(), t.exposedName, input)
	}
	var params struct {
		URI string `json:"uri"`
	}
	if err := json.Unmarshal(input, &params); err != nil || params.URI == "" {
		return tool.Result{Content: "uri is required", IsError: true}, nil
	}
	text, mimeType, err := t.client.ReadResource(ctx, params.URI)
	if err != nil {
		return tool.Result{Content: fmt.Sprintf("read resource failed: %v", err), IsError: true}, nil
	}
	content := text
	if mimeType != "" && mimeType != "text/plain" && mimeType != "text/plain; charset=utf-8" {
		content = fmt.Sprintf("[%s]\n%s", mimeType, text)
	}
	return tool.Result{Content: wrapUntrusted(t.client.Server(), t.exposedName, content, t.scanOutput)}, nil
}

// mcpPromptListTool lists available prompt templates from an MCP server.
type mcpPromptListTool struct {
	client      *Client
	exposedName string
	capability  tool.Capability
}

func (t *mcpPromptListTool) Name() string { return t.exposedName }
func (t *mcpPromptListTool) Description() string {
	return "List available prompt templates from the " + t.client.Server() + " MCP server"
}
func (t *mcpPromptListTool) Capability() tool.Capability { return t.capability }
func (t *mcpPromptListTool) InputSchema() json.RawMessage {
	return json.RawMessage(`{"type":"object","properties":{}}`)
}
func (t *mcpPromptListTool) Execute(ctx context.Context, _ json.RawMessage) (tool.Result, error) {
	prompts, err := t.client.ListPrompts(ctx)
	if err != nil {
		return tool.Result{Content: fmt.Sprintf("list prompts failed: %v", err), IsError: true}, nil
	}
	if len(prompts) == 0 {
		return tool.Result{Content: "no prompts available"}, nil
	}
	data, _ := json.Marshal(prompts)
	return tool.Result{Content: string(data)}, nil
}

// mcpPromptGetTool retrieves a named prompt template with its rendered messages.
type mcpPromptGetTool struct {
	client      *Client
	exposedName string
	capability  tool.Capability
	scanOutput  bool
	scanArgs    bool
	logger      *slog.Logger
}

func (t *mcpPromptGetTool) Name() string { return t.exposedName }
func (t *mcpPromptGetTool) Description() string {
	return "Get a prompt template by name from the " + t.client.Server() + " MCP server"
}
func (t *mcpPromptGetTool) Capability() tool.Capability { return t.capability }
func (t *mcpPromptGetTool) InputSchema() json.RawMessage {
	return json.RawMessage(`{"type":"object","properties":{"name":{"type":"string","description":"Prompt name"},"arguments":{"type":"object","description":"Prompt arguments as key-value pairs","additionalProperties":{"type":"string"}}},"required":["name"]}`)
}
func (t *mcpPromptGetTool) Execute(ctx context.Context, input json.RawMessage) (tool.Result, error) {
	if t.scanArgs {
		warnOutboundSecrets(t.logger, t.client.Server(), t.exposedName, input)
	}
	var params struct {
		Name      string            `json:"name"`
		Arguments map[string]string `json:"arguments"`
	}
	if err := json.Unmarshal(input, &params); err != nil || params.Name == "" {
		return tool.Result{Content: "name is required", IsError: true}, nil
	}
	desc, messages, err := t.client.GetPrompt(ctx, params.Name, params.Arguments)
	if err != nil {
		return tool.Result{Content: fmt.Sprintf("get prompt failed: %v", err), IsError: true}, nil
	}
	var sb strings.Builder
	if desc != "" {
		sb.WriteString(desc)
		sb.WriteString("\n\n")
	}
	for _, m := range messages {
		fmt.Fprintf(&sb, "[%s]: %s\n", m.Role, m.Content.Text)
	}
	return tool.Result{Content: wrapUntrusted(t.client.Server(), t.exposedName, strings.TrimSpace(sb.String()), t.scanOutput)}, nil
}

// ServerConfig configures one MCP server.
type ServerConfig struct {
	Name    string            `koanf:"name"`
	Command string            `koanf:"command"`
	Args    []string          `koanf:"args"`
	Env     map[string]string `koanf:"env"`
	Auth    string            `koanf:"auth"` // Bearer token for HTTP servers
	// Capability is the default tool.Capability assigned to every tool this
	// server exposes: "read", "write", "network", "execute", or "spawn".
	// Empty/unrecognized defaults to "execute" — the most restrictive class —
	// so an unlabeled or untrusted server's tools hit the Ask gate in build
	// mode and are denied outright in plan mode, instead of silently
	// inheriting the always-allowed "network" capability (P7.1).
	Capability string `koanf:"capability"`
	// ToolCapabilities overrides Capability per remote tool name (as reported
	// by the server's tools/list, before the mcp__<server>__ namespace
	// prefix is applied) for servers that expose a known mix of tools.
	ToolCapabilities map[string]string `koanf:"tool_capabilities"`
	// ScanOutput opts this server's tool/resource/prompt output into a
	// heuristic prompt-injection scan before it reaches the model (P21.6).
	// Off by default — it's a best-effort heuristic with false positives, so
	// it only runs for servers the operator has flagged as not fully
	// trusted. The provenance marker (see wrapUntrusted) is always applied
	// regardless of this flag.
	ScanOutput bool `koanf:"scan_output"`
	// ScanArguments opts outbound tool-call arguments bound for this server
	// into a heuristic secret-pattern check before they are forwarded
	// (P24.14, FIND-12). Arguments are model-constructed and may carry
	// anything the model has read into context, so an untrusted server is a
	// potential exfiltration channel. Off by default; a hit logs a Warn
	// naming the server, tool, and pattern class — flag-only, the call is
	// never blocked or mutated. The outbound mirror of ScanOutput.
	ScanArguments bool `koanf:"scan_arguments"`
}

// parseCapability maps a config capability string to a tool.Capability,
// defaulting anything empty or unrecognized to the most restrictive class,
// tool.CapExecute, so it always requires approval (or is denied in plan
// mode) rather than silently inheriting a permissive capability.
func parseCapability(s string) tool.Capability {
	switch s {
	case "read":
		return tool.CapRead
	case "write":
		return tool.CapWrite
	case "network":
		return tool.CapNetwork
	case "spawn":
		return tool.CapSpawn
	default:
		return tool.CapExecute
	}
}

// resolveCapability returns the capability for a specific remote tool name,
// preferring a per-tool override over the server's default.
func resolveCapability(sc ServerConfig, toolName string) tool.Capability {
	if c, ok := sc.ToolCapabilities[toolName]; ok {
		return parseCapability(c)
	}
	return parseCapability(sc.Capability)
}

// RegisterServers connects each configured MCP server, registers its tools
// (namespaced as mcp__<server>__<tool>), and returns the live clients for
// later cleanup. A server that fails to connect is logged and skipped.
//
// For servers that support resources or prompts, additional tools are registered:
//   - mcp__<server>__list_resources / mcp__<server>__read_resource
//   - mcp__<server>__list_prompts  / mcp__<server>__get_prompt
//
// Dynamic refresh: if the server sends a notifications/tools/list_changed
// notification, the tool list is re-fetched and the registry is updated.
func RegisterServers(ctx context.Context, reg *tool.Registry, servers []ServerConfig, logger *slog.Logger) []*Client {
	var clients []*Client
	for _, sc := range servers {
		if sc.Command == "" || sc.Name == "" {
			continue
		}
		client, err := NewHTTPOrStdio(ctx, sc)
		if err != nil {
			logger.Warn("mcp server connect failed", "server", sc.Name, "err", err)
			continue
		}
		serverNameForLog := sc.Name
		client.onReadError = func(readErr error) {
			logger.Warn("mcp connection lost", "server", serverNameForLog, "err", readErr)
		}

		tools, err := client.ListTools(ctx)
		if err != nil {
			logger.Warn("mcp list tools failed", "server", sc.Name, "err", err)
			_ = client.Close()
			continue
		}
		for _, info := range tools {
			name := fmt.Sprintf("mcp__%s__%s", sc.Name, info.Name)
			cap := resolveCapability(sc, info.Name)
			if err := reg.Register(&mcpTool{client: client, info: info, exposedName: name, capability: cap, scanOutput: sc.ScanOutput, scanArgs: sc.ScanArguments, logger: logger}); err != nil {
				logger.Warn("mcp tool register failed", "tool", name, "err", err)
			}
		}

		// Meta-tools (resource/prompt listing) are fixed, protocol-defined
		// operations rather than server-defined behavior, but they still
		// proxy to a possibly-untrusted server, so they take the server's
		// default capability rather than a hardcoded one.
		metaCap := parseCapability(sc.Capability)

		// Probe resources support. Servers that don't implement resources/list
		// return an MCP error; we skip registration silently in that case.
		if _, err := client.ListResources(ctx); err == nil {
			prefix := fmt.Sprintf("mcp__%s", sc.Name)
			_ = reg.Register(&mcpResourceListTool{client: client, exposedName: prefix + "__list_resources", capability: metaCap})
			_ = reg.Register(&mcpResourceReadTool{client: client, exposedName: prefix + "__read_resource", capability: metaCap, scanOutput: sc.ScanOutput, scanArgs: sc.ScanArguments, logger: logger})
			logger.Info("mcp resources registered", "server", sc.Name)
		}

		// Probe prompts support similarly.
		if _, err := client.ListPrompts(ctx); err == nil {
			prefix := fmt.Sprintf("mcp__%s", sc.Name)
			_ = reg.Register(&mcpPromptListTool{client: client, exposedName: prefix + "__list_prompts", capability: metaCap})
			_ = reg.Register(&mcpPromptGetTool{client: client, exposedName: prefix + "__get_prompt", capability: metaCap, scanOutput: sc.ScanOutput, scanArgs: sc.ScanArguments, logger: logger})
			logger.Info("mcp prompts registered", "server", sc.Name)
		}

		// Wire dynamic tool refresh: re-list and upsert on tools/list_changed.
		if reg != nil {
			serverName := sc.Name
			serverCfg := sc
			cl := client
			client.onToolsChanged = func() {
				newTools, err := cl.ListTools(ctx)
				if err != nil {
					logger.Warn("mcp tool refresh failed", "server", serverName, "err", err)
					return
				}
				for _, info := range newTools {
					name := fmt.Sprintf("mcp__%s__%s", serverName, info.Name)
					reg.Upsert(&mcpTool{client: cl, info: info, exposedName: name, capability: resolveCapability(serverCfg, info.Name), scanOutput: serverCfg.ScanOutput, scanArgs: serverCfg.ScanArguments, logger: logger})
				}
				logger.Info("mcp tools refreshed", "server", serverName, "tools", len(newTools))
			}
		}

		logger.Info("mcp server connected", "server", sc.Name, "tools", len(tools))
		clients = append(clients, client)
	}
	return clients
}

func flattenEnv(env map[string]string) []string {
	out := make([]string, 0, len(env))
	for k, v := range env {
		out = append(out, k+"="+v)
	}
	return out
}
